
public class Pair<E, F> {
	E e;
	F f;
	Pair(E e, F f) {
		this.e = e;
		this.f = f;
	}
}
